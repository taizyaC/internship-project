
const endpoints = {
    users: "https://whitebook-engine.kuala.io/get-users",
    organizations: "https://whitebook-engine.kuala.io/get-organizations",
    classes: "https://whitebook-engine.kuala.io/get-classes",
    products: "https://whitebook-engine.kuala.io/get-products",
    wordings: "https://whitebook-engine.kuala.io/get-wordings",
    packageBenefits: "https://whitebook-engine.kuala.io/get-package-benefits"
  };
  async function fetchDataAndUpdate(endpoint, elementId) {
    try {
      const response = await fetch(endpoint);
      const data = await response.json();
      const count = data.data.length; 
      document.getElementById(elementId).textContent = count;
    } catch (error) {
      console.error("Error fetching data:", error);
      document.getElementById(elementId).textContent = "Error";
    }
  }
  fetchDataAndUpdate(endpoints.users, "users-count");
  fetchDataAndUpdate(endpoints.organizations, "organizations-count");
  fetchDataAndUpdate(endpoints.classes, "classes-count");
  fetchDataAndUpdate(endpoints.products, "products-count");
  fetchDataAndUpdate(endpoints.wordings, "wordings-count");
  fetchDataAndUpdate(endpoints.packageBenefits, "package-benefits-count");
  